call create_sequence('mvc_board');
select * from sequences;