-- name 시퀀스명
-- currval 현재값, bigint unsigned 
-- => 음수없음, 매우 큰 값

create table sequences (
	name varchar(32),
    currval bigint unsigned
);




