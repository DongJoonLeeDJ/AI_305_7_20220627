package board;

public class BoardDTO {
	int num;
	String name;
	String tel;
	String email;
	String title;
	String content_password;
	String rank;
	String update_time;
	int view_count;
	int ref;
	int post_step;
	int post_depth;
	String content;
	String ipAddress;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent_password() {
		return content_password;
	}
	public void setContent_password(String content_password) {
		this.content_password = content_password;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public String getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}
	public int getView_count() {
		return view_count;
	}
	public void setView_count(int view_count) {
		this.view_count = view_count;
	}
	public int getRef() {
		return ref;
	}
	public void setRef(int ref) {
		this.ref = ref;
	}
	public int getPost_step() {
		return post_step;
	}
	public void setPost_step(int post_step) {
		this.post_step = post_step;
	}
	public int getPost_depth() {
		return post_depth;
	}
	public void setPost_depth(int post_depth) {
		this.post_depth = post_depth;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
}
