package Member;

public interface DBinfo {
	public interface DBInfo {
		String mysql_class = "com.mysql.cj.jdbc.Driver";
		String mysql_url = "jdbc:mysql://192.168.0.104:3306/charge?useUnicode=yes&characterEncoding=UTF8";
		String mysql_id = "root";
		String mysql_pw = "1234";
	}

}
