package example;

public interface DBInfo {
	String mysql_class = "com.mysql.cj.jdbc.Driver";
	String mysql_url = "jdbc:mysql://localhost:3306/jsp_teamproject?useUnicode=yes&characterEncoding=UTF8&zeroDateTimeBehavior=convertToNull";
	String mysql_id = "root";
	String mysql_pw = "1234";
}
