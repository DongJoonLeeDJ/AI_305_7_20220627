﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeThreadWork
{
    public class DataManager
    {
        public static List<User> users = new List<User>();
    }
}
