#include<stdio.h>
#include<stdlib.h>
#include<time.h>

void main()
{
	int lotto[6]=
}