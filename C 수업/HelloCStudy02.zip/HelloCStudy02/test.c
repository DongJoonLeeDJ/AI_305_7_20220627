#include<stdio.h>
int main()
{

	double a;
	scanf_s("%lf", &a);
	printf("%f", a);
	return 0;
}